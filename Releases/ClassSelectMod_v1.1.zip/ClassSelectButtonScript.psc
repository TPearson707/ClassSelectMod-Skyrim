Scriptname ClassSelectButtonScript extends ObjectReference  

{Script to give the player class gear}

Message Property Question Auto

;Ask the player what class they want the starting gear for

Message Property Warrior Auto 
Message Property Thief Auto
Message Property Assassin Auto
Message Property Mage Auto

;Warrior class starting spec

;Armor
Armor Property EnchArmorSteelHelmetMarksman03 Auto
Armor Property EnchArmorSteelCuirassHealth03 Auto
Armor Property EnchArmorSteelGauntletsOneHanded03 Auto
Armor Property EnchArmorSteelBootsStamina03 Auto
Armor Property EnchArmorSteelShieldBlock03 Auto

;Weapons
Weapon Property SkyforgeSteelSword Auto 

;Accessories
Armor Property ReligiousTalosMankind Auto

;Misc Gear
Potion Property RestoreHealth02 Auto 
Potion Property RestoreStamina02 Auto 

;Thief class starting spec

;Armor
Armor Property ArmorThievesGuildHelmetPlayerImproved Auto
Armor Property ArmorThievesGuildCuirassPlayerImproved Auto
Armor Property ArmorThievesGuildGauntletsPlayerImproved Auto
Armor Property ArmorThievesGuildBootsPlayerImproved Auto

;Weapons
Weapon Property dunMossMotherValdrDagger Auto
Weapon Property EnchHuntingBowFire1 Auto
Ammo Property SteelArrow Auto

;Accessories
Armor Property TGAmuletofArticulation07 Auto

;Misc Gear
MiscObject Property Lockpick Auto 

;Assassin class starting spec

;Armor
Armor Property DBArmorHelmet Auto
Armor Property DBArmor Auto
Armor Property DBArmorGloves Auto
Armor Property DBArmorBoots Auto

;Weapons - Friniel's End
Weapon Property DB05ElvenBow Auto
Ammo Property ElvenArrow Auto

;Accessories
Armor Property DBMuiriRing Auto

;Misc Gear
Potion Property DamageHealth02 Auto
Potion Property Paralyze02 Auto

;Mage class starting spec

;Armor
Armor Property EnchClothesRobesMageHoodApprentice Auto
Armor Property EnchClothesRobesMageDestruction02 Auto
Armor Property ClothesCollegeBootsApprenticeVariant1 Auto

;Weapons
Weapon Property StaffChainLightning Auto

;Spell List
Book Property TomeFirebolt Auto
Book Property TomeLightningBolt Auto
Book Property TomeIceSpike Auto

;Accessories
Armor Property EnchNecklaceMagicka03 Auto
Armor Property EnchRingMagickaRate03 Auto

;Misc Gear
SoulGem Property SoulGemCommonFilled Auto
SoulGem Property SoulGemGreaterFilled Auto
SoulGem Property SoulGemGrandFilled Auto


int Button

;Event logic
EVENT onActivate(objectReference akActionRef)

    If akActionRef == Game.GetPlayer()
        Button = Question.Show()

        If Button == 0
            Warrior.Show()

            Game.GetPlayer().AddItem(EnchArmorSteelHelmetMarksman03, 1, false)
            Game.GetPlayer().AddItem(EnchArmorSteelCuirassHealth03, 1, false)
            Game.GetPlayer().AddItem(EnchArmorSteelGauntletsOneHanded03, 1, false)
            Game.GetPlayer().AddItem(EnchArmorSteelBootsStamina03, 1, false)

            Game.GetPlayer().AddItem(SkyforgeSteelSword, 1, false)
            Game.GetPlayer().AddItem(EnchArmorSteelShieldBlock03, 1, false)

            Game.GetPlayer().AddItem(ReligiousTalosMankind, 1, false)

            Game.GetPlayer().AddItem(RestoreHealth02, 5, false)
            Game.GetPlayer().AddItem(RestoreStamina02, 5, false)
        ElseIf (Button == 1)
            Thief.Show()

            Game.GetPlayer().AddItem(ArmorThievesGuildHelmetPlayerImproved, 1, false)
            Game.GetPlayer().AddItem(ArmorThievesGuildCuirassPlayerImproved, 1, false)
            Game.GetPlayer().AddItem(ArmorThievesGuildGauntletsPlayerImproved, 1, false)
            Game.GetPlayer().AddItem(ArmorThievesGuildBootsPlayerImproved, 1, false)

            Game.GetPlayer().AddItem(dunMossMotherValdrDagger, 1, false)
            Game.GetPlayer().AddItem(EnchHuntingBowFire1 , 1, false)
            Game.GetPlayer().AddItem(SteelArrow, 50, false)

            Game.GetPlayer().AddItem(TGAmuletofArticulation07, 1, false)

            Game.GetPlayer().AddItem(Lockpick, 20, false)
        ElseIf (Button == 2)
            Assassin.Show()

            Game.GetPlayer().AddItem(DBArmorHelmet, 1, false)
            Game.GetPlayer().AddItem(DBArmor, 1, false)
            Game.GetPlayer().AddItem(DBArmorGloves, 1, false)
            Game.GetPlayer().AddItem(DBArmorBoots, 1, false)

            Game.GetPlayer().AddItem(DB05ElvenBow, 1, false)
            Game.GetPlayer().AddItem(ElvenArrow, 50, false)

            Game.GetPlayer().AddItem(DBMuiriRing, 1, false)

            Game.GetPlayer().AddItem(DamageHealth02, 5, false)
            Game.GetPlayer().AddItem(Paralyze02, 5, false)
        ElseIf (Button == 3)
            Mage.Show()

            Game.GetPlayer().AddItem(EnchClothesRobesMageHoodApprentice, 1, false)
            Game.GetPlayer().AddItem(EnchClothesRobesMageDestruction02, 1, false)
            Game.GetPlayer().AddItem(ClothesCollegeBootsApprenticeVariant1, 1, false)

            Game.GetPlayer().AddItem(StaffChainLightning, 1, false)

            Game.GetPlayer().AddItem(TomeFirebolt, 1, false)
            Game.GetPlayer().AddItem(TomeLightningBolt, 1, false)
            Game.GetPlayer().AddItem(TomeIceSpike, 1, false)

            Game.GetPlayer().AddItem(EnchNecklaceMagicka03, 1, false)
            Game.GetPlayer().AddItem(EnchRingMagickaRate03, 1, false)

            Game.GetPlayer().AddItem(SoulGemCommonFilled, 3, false)
            Game.GetPlayer().AddItem(SoulGemGreaterFilled, 2, false)
            Game.GetPlayer().AddItem(SoulGemGrandFilled, 1, false)
        EndIf
    EndIf
endEVENT